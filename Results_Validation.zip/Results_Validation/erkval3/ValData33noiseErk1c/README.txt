Results generated on 08/04/15 at 11:28:10
P-value threshold used: 1.0
Number of permutations performed: 0